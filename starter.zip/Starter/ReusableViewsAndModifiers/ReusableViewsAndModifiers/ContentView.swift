//
//  ContentView.swift
//  ReusableViewsAndModifiers
//
//  Created by Gabriel Theodoropoulos.
//

import SwiftUI

struct ContentView: View {
    @State var progress: Double = 0
    
    var body: some View {
        VStack {
            Button(action: {
                self.progress += 10
            }, label: {
                Text("Update Progress")
            })
            .padding(8)
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
            
            
            // Use the progress view here
            
            
            Button(action: {
                self.progress = 0
            }, label: {
                Text("Reset Progress")
            })
            .padding(.top, 40)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
